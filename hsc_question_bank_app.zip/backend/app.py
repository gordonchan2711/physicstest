"""
app.py — Flask backend for the HSC question bank app.

Endpoints:
  POST   /api/upload            multipart: exam_pdf (required), guidelines_pdf (optional)
  GET    /api/papers            list all uploaded papers
  GET    /api/questions         list questions, filterable by ?subject=&year=&paper_id=&q=(topic search)
  DELETE /api/papers/<id>       remove a paper and its questions/images
  GET    /static/questions/...  serves extracted question images

Run locally:
    pip install -r requirements.txt
    python3 app.py
    -> http://localhost:5000

Data persists in backend/hsc_bank.db (SQLite) and backend/static/questions/
(image files). Both need to live on a persistent volume when deployed.
"""
import os
import sqlite3
import json
import uuid
import tempfile
import shutil
from datetime import datetime, timezone

from flask import Flask, request, jsonify, send_from_directory, g
from flask_cors import CORS

import extractor

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(os.path.dirname(BASE_DIR), 'frontend')
DB_PATH = os.path.join(BASE_DIR, 'hsc_bank.db')
QUESTIONS_DIR = os.path.join(BASE_DIR, 'static', 'questions')
os.makedirs(QUESTIONS_DIR, exist_ok=True)

app = Flask(__name__, static_folder=None)
CORS(app)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB upload cap


@app.route('/')
def serve_index():
    return send_from_directory(FRONTEND_DIR, 'index.html')


@app.route('/<path:filename>')
def serve_frontend_file(filename):
    # Serves style.css, app.js, manifest.json, sw.js, icons/... directly.
    # /static/questions/... is matched by the more specific route below
    # first, since Flask prefers the longer/more specific rule.
    if os.path.exists(os.path.join(FRONTEND_DIR, filename)):
        return send_from_directory(FRONTEND_DIR, filename)
    return jsonify({'error': 'not found'}), 404


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS papers (
            id TEXT PRIMARY KEY,
            subject TEXT NOT NULL,
            year TEXT NOT NULL,
            exam_filename TEXT,
            guidelines_filename TEXT,
            uploaded_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS questions (
            id TEXT PRIMARY KEY,
            paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
            question_number INTEGER NOT NULL,
            section INTEGER,
            image_path TEXT NOT NULL,
            marks INTEGER,
            content TEXT,
            syllabus_outcomes TEXT
        );
    ''')
    conn.commit()
    conn.close()


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------

@app.route('/api/upload', methods=['POST'])
def upload():
    exam_file = request.files.get('exam_pdf')
    guidelines_file = request.files.get('guidelines_pdf')
    if not exam_file:
        return jsonify({'error': 'exam_pdf file is required'}), 400

    paper_id = str(uuid.uuid4())[:8]
    tmp_dir = tempfile.mkdtemp(prefix='hsc_upload_')
    try:
        exam_path = os.path.join(tmp_dir, exam_file.filename)
        exam_file.save(exam_path)

        guidelines_path = None
        if guidelines_file and guidelines_file.filename:
            guidelines_path = os.path.join(tmp_dir, guidelines_file.filename)
            guidelines_file.save(guidelines_path)

        paper_out_dir = os.path.join(QUESTIONS_DIR, paper_id)
        os.makedirs(paper_out_dir, exist_ok=True)

        try:
            result = extractor.process_paper(
                exam_path, guidelines_path, paper_out_dir,
                exam_filename=exam_file.filename,
            )
        except Exception as e:
            shutil.rmtree(paper_out_dir, ignore_errors=True)
            return jsonify({'error': f'Extraction failed: {e}'}), 500

        db = get_db()
        db.execute(
            'INSERT INTO papers (id, subject, year, exam_filename, guidelines_filename, uploaded_at) '
            'VALUES (?, ?, ?, ?, ?, ?)',
            (paper_id, result['subject'], result['year'], exam_file.filename,
             guidelines_file.filename if guidelines_file else None,
             datetime.now(timezone.utc).isoformat())
        )
        for q in result['questions']:
            db.execute(
                'INSERT INTO questions (id, paper_id, question_number, section, image_path, '
                'marks, content, syllabus_outcomes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                (str(uuid.uuid4())[:8], paper_id, q['question'], q['section'],
                 f"{paper_id}/{q['filename']}", q.get('marks'),
                 json.dumps(q.get('content', [])),
                 json.dumps(q.get('syllabus_outcomes', [])))
            )
        db.commit()

        return jsonify({
            'paper_id': paper_id,
            'subject': result['subject'],
            'year': result['year'],
            'question_count': len(result['questions']),
        })
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


@app.route('/api/papers', methods=['GET'])
def list_papers():
    db = get_db()
    rows = db.execute(
        'SELECT p.*, COUNT(q.id) as question_count FROM papers p '
        'LEFT JOIN questions q ON q.paper_id = p.id '
        'GROUP BY p.id ORDER BY p.uploaded_at DESC'
    ).fetchall()
    return jsonify([dict(r) for r in rows])


@app.route('/api/papers/<paper_id>', methods=['DELETE'])
def delete_paper(paper_id):
    db = get_db()
    db.execute('DELETE FROM questions WHERE paper_id = ?', (paper_id,))
    db.execute('DELETE FROM papers WHERE id = ?', (paper_id,))
    db.commit()
    shutil.rmtree(os.path.join(QUESTIONS_DIR, paper_id), ignore_errors=True)
    return jsonify({'ok': True})


@app.route('/api/questions', methods=['GET'])
def list_questions():
    db = get_db()
    clauses, params = [], []
    if request.args.get('subject'):
        clauses.append('p.subject = ?')
        params.append(request.args['subject'])
    if request.args.get('year'):
        clauses.append('p.year = ?')
        params.append(request.args['year'])
    if request.args.get('paper_id'):
        clauses.append('p.id = ?')
        params.append(request.args['paper_id'])
    if request.args.get('q'):
        clauses.append('(q.content LIKE ? OR q.syllabus_outcomes LIKE ?)')
        like = f"%{request.args['q']}%"
        params.extend([like, like])

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ''
    rows = db.execute(
        f'SELECT q.*, p.subject, p.year FROM questions q '
        f'JOIN papers p ON p.id = q.paper_id {where} '
        f'ORDER BY p.year DESC, q.question_number ASC',
        params
    ).fetchall()

    out = []
    for r in rows:
        d = dict(r)
        d['content'] = json.loads(d['content'] or '[]')
        d['syllabus_outcomes'] = json.loads(d['syllabus_outcomes'] or '[]')
        d['image_url'] = f"/static/questions/{d['image_path']}"
        out.append(d)
    return jsonify(out)


@app.route('/static/questions/<path:filepath>')
def serve_question_image(filepath):
    return send_from_directory(QUESTIONS_DIR, filepath)


@app.route('/api/health')
def health():
    return jsonify({'status': 'ok'})


if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)
