const API = ''; // same-origin; set to e.g. 'http://localhost:5000' if serving frontend separately

let examFile = null;
let guideFile = null;
let allQuestions = [];
let allPapers = [];

// ---------- Dropzones ----------

function setupDropzone(zoneId, inputId, labelId, kind) {
  const zone = document.getElementById(zoneId);
  const input = document.getElementById(inputId);
  const label = document.getElementById(labelId);

  zone.addEventListener('click', () => input.click());
  input.addEventListener('change', () => handleFile(input.files[0], kind, label));

  ['dragenter', 'dragover'].forEach(evt =>
    zone.addEventListener(evt, e => { e.preventDefault(); zone.classList.add('dragover'); })
  );
  ['dragleave', 'drop'].forEach(evt =>
    zone.addEventListener(evt, e => { e.preventDefault(); zone.classList.remove('dragover'); })
  );
  zone.addEventListener('drop', e => {
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file, kind, label);
  });
}

function handleFile(file, kind, labelEl) {
  if (!file) return;
  if (file.type !== 'application/pdf') {
    labelEl.textContent = 'Please choose a PDF file.';
    return;
  }
  labelEl.textContent = file.name;
  if (kind === 'exam') examFile = file;
  else guideFile = file;
  updateProcessBtn();
}

function updateProcessBtn() {
  document.getElementById('processBtn').disabled = !examFile;
}

setupDropzone('examDrop', 'examInput', 'examFileName', 'exam');
setupDropzone('guideDrop', 'guideInput', 'guideFileName', 'guide');

// ---------- Upload / process ----------

document.getElementById('processBtn').addEventListener('click', async () => {
  const btn = document.getElementById('processBtn');
  const status = document.getElementById('statusLine');
  btn.disabled = true;
  status.className = 'status-line';
  status.textContent = 'Uploading and extracting — this can take a minute for long papers…';

  const form = new FormData();
  form.append('exam_pdf', examFile);
  if (guideFile) form.append('guidelines_pdf', guideFile);

  try {
    const res = await fetch(`${API}/api/upload`, { method: 'POST', body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Upload failed');

    status.className = 'status-line success';
    status.textContent = `Done — extracted ${data.question_count} questions from ${data.subject} ${data.year}.`;

    examFile = null; guideFile = null;
    document.getElementById('examFileName').textContent = '';
    document.getElementById('guideFileName').textContent = '';
    document.getElementById('examInput').value = '';
    document.getElementById('guideInput').value = '';

    await loadEverything();
  } catch (err) {
    status.className = 'status-line error';
    status.textContent = `Error: ${err.message}`;
  } finally {
    updateProcessBtn();
  }
});

// ---------- Loading data ----------

async function loadPapers() {
  const res = await fetch(`${API}/api/papers`);
  allPapers = await res.json();
  renderPapersStrip();
  renderFilterOptions();
}

async function loadQuestions() {
  const params = new URLSearchParams();
  const subject = document.getElementById('subjectFilter').value;
  const year = document.getElementById('yearFilter').value;
  const topic = document.getElementById('topicSearch').value.trim();
  if (subject) params.set('subject', subject);
  if (year) params.set('year', year);
  if (topic) params.set('q', topic);

  const res = await fetch(`${API}/api/questions?${params.toString()}`);
  allQuestions = await res.json();
  renderGallery();
}

async function loadEverything() {
  await loadPapers();
  await loadQuestions();
  document.getElementById('totalCount').textContent =
    `${allQuestions.length} question${allQuestions.length === 1 ? '' : 's'} catalogued`;
}

// ---------- Rendering ----------

function renderPapersStrip() {
  const strip = document.getElementById('papersStrip');
  strip.innerHTML = '';
  allPapers.forEach(p => {
    const chip = document.createElement('div');
    chip.className = 'paper-chip';
    chip.innerHTML = `<span>${p.subject} ${p.year} · ${p.question_count}q</span>`;
    const del = document.createElement('button');
    del.textContent = '\u2715';
    del.title = 'Remove this paper';
    del.addEventListener('click', async () => {
      if (!confirm(`Remove ${p.subject} ${p.year} and all ${p.question_count} of its questions?`)) return;
      await fetch(`${API}/api/papers/${p.id}`, { method: 'DELETE' });
      await loadEverything();
    });
    chip.appendChild(del);
    strip.appendChild(chip);
  });
}

function renderFilterOptions() {
  const subjectSel = document.getElementById('subjectFilter');
  const yearSel = document.getElementById('yearFilter');
  const curSubject = subjectSel.value, curYear = yearSel.value;

  const subjects = [...new Set(allPapers.map(p => p.subject))].sort();
  const years = [...new Set(allPapers.map(p => p.year))].sort().reverse();

  subjectSel.innerHTML = '<option value="">All subjects</option>' +
    subjects.map(s => `<option value="${s}">${s}</option>`).join('');
  yearSel.innerHTML = '<option value="">All years</option>' +
    years.map(y => `<option value="${y}">${y}</option>`).join('');

  subjectSel.value = curSubject;
  yearSel.value = curYear;
}

function renderGallery() {
  const gallery = document.getElementById('gallery');
  gallery.innerHTML = '';

  if (allQuestions.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'empty-state';
    empty.textContent = allPapers.length === 0
      ? 'No questions yet. Upload a past paper above to start building your bank.'
      : 'No questions match these filters.';
    gallery.appendChild(empty);
    return;
  }

  allQuestions.forEach(q => {
    const card = document.createElement('div');
    card.className = 'q-card';
    card.innerHTML = `
      <div class="q-thumb"><img loading="lazy" src="${API}${q.image_url}" alt="Question ${q.question_number}"></div>
      <div class="q-card-body">
        <div class="q-card-top">
          <span class="q-number">Q${q.question_number}</span>
          ${q.marks ? `<span class="q-marks">${q.marks} mark${q.marks === 1 ? '' : 's'}</span>` : ''}
        </div>
        <div class="q-source">${q.subject} · ${q.year}</div>
        <div class="q-tags">
          ${(q.content || []).slice(0, 2).map(c => `<span class="q-tag">${c}</span>`).join('')}
        </div>
      </div>
    `;
    card.addEventListener('click', () => openLightbox(q));
    gallery.appendChild(card);
  });
}

// ---------- Lightbox ----------

function openLightbox(q) {
  document.getElementById('lightboxImg').src = `${API}${q.image_url}`;
  const outcomes = (q.syllabus_outcomes || []).join(', ') || '—';
  const topics = (q.content || []).join(' · ') || '—';
  document.getElementById('lightboxMeta').innerHTML = `
    <strong>${q.subject} ${q.year} — Question ${q.question_number}</strong><br>
    Marks: ${q.marks ?? '—'}<br>
    Topic: ${topics}<br>
    Syllabus outcomes: ${outcomes}
  `;
  document.getElementById('lightbox').hidden = false;
}
document.getElementById('lightboxClose').addEventListener('click', () => {
  document.getElementById('lightbox').hidden = true;
});
document.getElementById('lightbox').addEventListener('click', e => {
  if (e.target.id === 'lightbox') document.getElementById('lightbox').hidden = true;
});

// ---------- Filters ----------

['subjectFilter', 'yearFilter'].forEach(id =>
  document.getElementById(id).addEventListener('change', loadQuestions)
);
document.getElementById('topicSearch').addEventListener('input', debounce(loadQuestions, 300));
document.getElementById('clearFilters').addEventListener('click', () => {
  document.getElementById('subjectFilter').value = '';
  document.getElementById('yearFilter').value = '';
  document.getElementById('topicSearch').value = '';
  loadQuestions();
});

function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

// ---------- PWA service worker ----------

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}

// ---------- Init ----------

loadEverything();
